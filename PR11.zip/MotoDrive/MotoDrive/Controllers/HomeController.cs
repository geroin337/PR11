﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.EntityFrameworkCore.Query.Internal;
using Microsoft.IdentityModel.Tokens;
using MotoDrive.Models;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Security.Claims;
using System.Text.Json;

namespace MotoDrive.Controllers
{
    public class HomeController : Controller
    {
        private Moto_Drive_DatabaseContext MotoBD;

        public HomeController(Moto_Drive_DatabaseContext context)
        {
            MotoBD = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Contats()
        {
            return View();
        }

        public IActionResult Trash()
        {
            Trash trashModel = new Trash();
            if (HttpContext.Session.Keys.Contains("Trash"))
                trashModel = JsonSerializer.Deserialize<Trash>(HttpContext.Session.GetString("Trash"));
            return View(trashModel);
        }

        public IActionResult AddToTrash()
        {
            int idMoto = Convert.ToInt32(Request.Query["IDMoto"]);
            int idEqup = Convert.ToInt32(Request.Query["IDEqup"]);
            int idPart = Convert.ToInt32(Request.Query["IDPart"]);
            Trash trashModel = new Trash();
            if (HttpContext.Session.Keys.Contains("Trash"))
                trashModel = JsonSerializer.Deserialize<Trash>(HttpContext.Session.GetString("Trash"));
            if (MotoBD.Motorcycles.Find(idMoto) != null)
                trashModel.TrashLinesMotorcycle.Add(MotoBD.Motorcycles.Find(idMoto));
            else if (MotoBD.MotorcycleEquipments.Find(idEqup) != null)
                trashModel.TrashLinesEquipment.Add(MotoBD.MotorcycleEquipments.Find(idEqup));
            else if (MotoBD.Parts.Find(idPart) != null)
                trashModel.TrashLinesPart.Add(MotoBD.Parts.Find(idPart));
            HttpContext.Session.SetString("Trash", JsonSerializer.Serialize<Trash>(trashModel));
            return Redirect("~/Home/Index");
        }

        public IActionResult RemoveFromTrashMoto()
        {
            int number = Convert.ToInt32(Request.Query["Number"]);
            Trash trashModel = new Trash();
            if (HttpContext.Session.Keys.Contains("Trash"))
                trashModel = JsonSerializer.Deserialize<Trash>(HttpContext.Session.GetString("Trash"));
            trashModel.TrashLinesMotorcycle.RemoveAt(number);
            HttpContext.Session.SetString("Trash", JsonSerializer.Serialize<Trash>(trashModel));
            return Redirect("~/Home/Trash");
        }

        public IActionResult RemoveFromTrashEqup()
        {
            int number = Convert.ToInt32(Request.Query["Number"]);
            Trash trashModel = new Trash();
            if (HttpContext.Session.Keys.Contains("Trash"))
                trashModel = JsonSerializer.Deserialize<Trash>(HttpContext.Session.GetString("Trash"));
            trashModel.TrashLinesEquipment.RemoveAt(number);
            HttpContext.Session.SetString("Trash", JsonSerializer.Serialize<Trash>(trashModel));
            return Redirect("~/Home/Trash");
        }

        public IActionResult RemoveFromTrashPart()
        {
            int number = Convert.ToInt32(Request.Query["Number"]);
            Trash trashModel = new Trash();
            if (HttpContext.Session.Keys.Contains("Trash"))
                trashModel = JsonSerializer.Deserialize<Trash>(HttpContext.Session.GetString("Trash"));
            trashModel.TrashLinesPart.RemoveAt(number);
            HttpContext.Session.SetString("Trash", JsonSerializer.Serialize<Trash>(trashModel));
            return Redirect("~/Home/Trash");
        }

        public IActionResult RemoveAllFromTrash()
        {
            Trash trashModel = new Trash();
            if (HttpContext.Session.Keys.Contains("Trash"))
                trashModel = JsonSerializer.Deserialize<Trash>(HttpContext.Session.GetString("Trash"));
            for (int i = 0; i < trashModel.TrashLinesMotorcycle.Count; i++)
                trashModel.TrashLinesMotorcycle.RemoveAt(i);
            for (int i = 0; i < trashModel.TrashLinesEquipment.Count; i++)
                trashModel.TrashLinesEquipment.RemoveAt(i);
            for (int i = 0; i < trashModel.TrashLinesPart.Count; i++)
                trashModel.TrashLinesPart.RemoveAt(i);
            HttpContext.Session.SetString("Trash", JsonSerializer.Serialize<Trash>(trashModel));
            return Redirect("~/Home/Trash");
        }

        public IActionResult Enter()
        {
            if (HttpContext.Session.Keys.Contains("AuthUser"))
                return RedirectToAction("Enter", "Home");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Enter(EnterModel model)
        {
            if (ModelState.IsValid)
            {
                Client client = await MotoBD.Clients.FirstOrDefaultAsync(p => p.Login == model.Login && p.Password == model.Password);
                if (client != null)
                {
                    HttpContext.Session.SetString("AuthUser", model.Login);
                    await Authenticate(model.Login);
                    return RedirectToAction("Index" , "Home");
                }
                ModelState.AddModelError("", "Некорректные логин или пароль");
            }
            return RedirectToAction("Enter", "Home");
        }

        private async Task Authenticate(string UserName)
        {
            var claims = new List<Claim>
            {
                new Claim(ClaimsIdentity.DefaultNameClaimType, UserName)
            };
            ClaimsIdentity id = new ClaimsIdentity(claims, "ApplicationCookie", ClaimsIdentity.DefaultNameClaimType, ClaimsIdentity.DefaultRoleClaimType);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(id));
        }

        public async Task<IActionResult> LogOut()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Remove("AuthUser");
            return RedirectToAction("Enter");
        }

        public IActionResult Equipment()
        {
            return View();
        }

        public IActionResult Motocicle()
        {
            return View();
        }

        public IActionResult Parts()
        {
            return View();
        }

        public IActionResult Registration()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Registration(Client client)
        {
            if (ModelState.IsValid)
            {
                MotoBD.Clients.Add(client);
                await MotoBD.SaveChangesAsync();
                return RedirectToAction("Enter");
            }
            else
                return View(client);
        }

        public async Task<IActionResult> AllMoto()
        {
            var motorcycle = MotoBD.Motorcycles.Include(p => p.Color).Include(p => p.EngineCapacity).Include(p => p.MotorcycleBrand);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> Aprilia()
        {
            var motorcycle = MotoBD.Motorcycles.Include(p => p.Color).Include(p => p.EngineCapacity).Include(p => p.MotorcycleBrand);
            return View(await motorcycle.ToListAsync());
        }

        public async Task <IActionResult> BigDog()
        {
            var motorcycle = MotoBD.Motorcycles.Include(p => p.Color).Include(p => p.EngineCapacity).Include(p => p.MotorcycleBrand);
            return View(await motorcycle.ToListAsync());
        }

        public async Task <IActionResult> BMW()
        {
            var motorcycle = MotoBD.Motorcycles.Include(p => p.Color).Include(p => p.EngineCapacity).Include(p => p.MotorcycleBrand);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> Ducati()
        {
            var motorcycle = MotoBD.Motorcycles.Include(p => p.Color).Include(p => p.EngineCapacity).Include(p => p.MotorcycleBrand);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> Harley_Davidson()
        {
            var motorcycle = MotoBD.Motorcycles.Include(p => p.Color).Include(p => p.EngineCapacity).Include(p => p.MotorcycleBrand);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> Honda()
        {
            var motorcycle = MotoBD.Motorcycles.Include(p => p.Color).Include(p => p.EngineCapacity).Include(p => p.MotorcycleBrand);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> Kawasaki()
        {
            var motorcycle = MotoBD.Motorcycles.Include(p => p.Color).Include(p => p.EngineCapacity).Include(p => p.MotorcycleBrand);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> Suzuki()
        {
            var motorcycle = MotoBD.Motorcycles.Include(p => p.Color).Include(p => p.EngineCapacity).Include(p => p.MotorcycleBrand);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> Yamaha()
        {
            var motorcycle = MotoBD.Motorcycles.Include(p => p.Color).Include(p => p.EngineCapacity).Include(p => p.MotorcycleBrand);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> MotoBoots()
        {
            var motorcycle = MotoBD.MotorcycleEquipments.Include(p => p.Material).Include(p => p.TypeMotorcycleEquipment);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> MotoGlasses()
        {
            var motorcycle = MotoBD.MotorcycleEquipments.Include(p => p.Material).Include(p => p.TypeMotorcycleEquipment);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> MotoGloves()
        {
            var motorcycle = MotoBD.MotorcycleEquipments.Include(p => p.Material).Include(p => p.TypeMotorcycleEquipment);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> MotoHelmet()
        {
            var motorcycle = MotoBD.MotorcycleEquipments.Include(p => p.Material).Include(p => p.TypeMotorcycleEquipment);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> MotoOverall()
        {
            var motorcycle = MotoBD.MotorcycleEquipments.Include(p => p.Material).Include(p => p.TypeMotorcycleEquipment);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> MotoProtection()
        {
            var motorcycle = MotoBD.MotorcycleEquipments.Include(p => p.Material).Include(p => p.TypeMotorcycleEquipment);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> MotoBattery()
        {
            var motorcycle = MotoBD.Parts.Include(p => p.Material).Include(p => p.TypePart);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> MotoClutch()
        {
            var motorcycle = MotoBD.Parts.Include(p => p.Material).Include(p => p.TypePart);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> MotoFootRest()
        {
            var motorcycle = MotoBD.Parts.Include(p => p.Material).Include(p => p.TypePart);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> MotoFuelSystem()
        {
            var motorcycle = MotoBD.Parts.Include(p => p.Material).Include(p => p.TypePart);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> MotoHeadLight()
        {
            var motorcycle = MotoBD.Parts.Include(p => p.Material).Include(p => p.TypePart);
            return View(await motorcycle.ToListAsync());
        }

        public async Task<IActionResult> MotoRubber()
        {
            var motorcycle = MotoBD.Parts.Include(p => p.Material).Include(p => p.TypePart);
            return View(await motorcycle.ToListAsync());
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult End()
        {
            return View();

        }
    }
}