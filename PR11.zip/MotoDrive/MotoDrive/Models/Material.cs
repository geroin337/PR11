﻿using System;
using System.Collections.Generic;

namespace MotoDrive.Models
{
    public partial class Material
    {
        public Material()
        {
            MotorcycleEquipments = new HashSet<MotorcycleEquipment>();
            Parts = new HashSet<Part>();
        }

        public int IdMaterial { get; set; }
        public string TitleOfMaterial { get; set; } = null!;

        public virtual ICollection<MotorcycleEquipment> MotorcycleEquipments { get; set; }
        public virtual ICollection<Part> Parts { get; set; }
    }
}
