﻿namespace MotoDrive.Models
{
    public class Trash
    {
        public Trash()
        {
            TrashLinesMotorcycle = new List<Motorcycle>();
            TrashLinesEquipment = new List<MotorcycleEquipment>();
            TrashLinesPart = new List<Part>();
        }

        public List<Motorcycle> TrashLinesMotorcycle { get; set; }
        public List<MotorcycleEquipment> TrashLinesEquipment { get; set; }
        public List<Part> TrashLinesPart { get; set; }

        public int FinalPrice
        {
            get
            {
                int sum = 0;
                foreach (Motorcycle motorcycle in TrashLinesMotorcycle)
                {
                    sum += motorcycle.Price;
                }
                foreach (MotorcycleEquipment equipment in TrashLinesEquipment)
                {
                    sum += equipment.Price;
                }
                foreach (Part part in TrashLinesPart)
                {
                    sum += part.Price;
                }
                return sum;
            }
        }
    }
}
