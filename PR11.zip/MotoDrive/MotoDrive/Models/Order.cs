﻿using System;
using System.Collections.Generic;

namespace MotoDrive.Models
{
    public partial class Order
    {
        public int IdOrder { get; set; }
        public int MotorcycleId { get; set; }
        public int PartId { get; set; }
        public int ClientId { get; set; }
        public int MotorcycleEquipmentId { get; set; }

        public virtual Client Client { get; set; } = null!;
        public virtual Motorcycle Motorcycle { get; set; } = null!;
        public virtual Part Part { get; set; } = null!;
        public virtual MotorcycleEquipment MotorcycleEquipment { get; set; } = null!;
    }
}
