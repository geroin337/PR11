﻿using System;
using System.Collections.Generic;

namespace MotoDrive.Models
{
    public partial class Part
    {
        public int IdPart { get; set; }
        public int Price { get; set; }
        public int MaterialId { get; set; }
        public int TypePartId { get; set; }
        public byte[] PictureOfPart { get; set; } = null!;
        public string TitlePart { get; set; } = null!;

        public virtual Material Material { get; set; } = null!;
        public virtual TypePart TypePart { get; set; } = null!;
    }
}
