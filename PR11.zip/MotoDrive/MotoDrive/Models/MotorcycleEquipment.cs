﻿using System;
using System.Collections.Generic;

namespace MotoDrive.Models
{
    public partial class MotorcycleEquipment
    {
        public int IdMotorcycleEquipment { get; set; }
        public int Price { get; set; }
        public int MaterialId { get; set; }
        public int TypeMotorcycleEquipmentId { get; set; }
        public byte[] PictureOfMotorcycleEquipment { get; set; } = null!;
        public string TitleEquipment { get; set; } = null!;

        public virtual Material Material { get; set; } = null!;
        public virtual TypeMotorcycleEquipment TypeMotorcycleEquipment { get; set; } = null!;
    }
}
