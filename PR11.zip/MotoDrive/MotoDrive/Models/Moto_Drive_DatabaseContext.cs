﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace MotoDrive.Models
{
    public partial class Moto_Drive_DatabaseContext : DbContext
    {
        public Moto_Drive_DatabaseContext()
        {
        }

        public Moto_Drive_DatabaseContext(DbContextOptions<Moto_Drive_DatabaseContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Client> Clients { get; set; } = null!;
        public virtual DbSet<Color> Colors { get; set; } = null!;
        public virtual DbSet<EngineCapacity> EngineCapacities { get; set; } = null!;
        public virtual DbSet<Material> Materials { get; set; } = null!;
        public virtual DbSet<Motorcycle> Motorcycles { get; set; } = null!;
        public virtual DbSet<MotorcycleBrand> MotorcycleBrands { get; set; } = null!;
        public virtual DbSet<MotorcycleEquipment> MotorcycleEquipments { get; set; } = null!;
        public virtual DbSet<Order> Orders { get; set; } = null!;
        public virtual DbSet<Part> Parts { get; set; } = null!;
        public virtual DbSet<TypeMotorcycleEquipment> TypeMotorcycleEquipments { get; set; } = null!;
        public virtual DbSet<TypePart> TypeParts { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=DESKTOP-BA89SQ3\\MYSERVER;Initial Catalog=Moto_Drive_Database;User ID=sa;Password=123");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Client>(entity =>
            {
                entity.HasKey(e => e.IdClient);

                entity.ToTable("Client");

                entity.Property(e => e.IdClient).HasColumnName("ID_Client");

                entity.Property(e => e.EMail)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("E-mail");

                entity.Property(e => e.Login)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Color>(entity =>
            {
                entity.HasKey(e => e.IdColor);

                entity.ToTable("Color");

                entity.HasIndex(e => e.TitleColor, "UQ_Title_Color")
                    .IsUnique();

                entity.Property(e => e.IdColor).HasColumnName("ID_Color");

                entity.Property(e => e.TitleColor)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Title_Color");
            });

            modelBuilder.Entity<EngineCapacity>(entity =>
            {
                entity.HasKey(e => e.IdEngineCapacity);

                entity.ToTable("Engine_Capacity");

                entity.HasIndex(e => e.EngineCapacity1, "UQ_Engine_Capacity")
                    .IsUnique();

                entity.Property(e => e.IdEngineCapacity).HasColumnName("ID_Engine_Capacity");

                entity.Property(e => e.EngineCapacity1)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("Engine_Capacity");
            });

            modelBuilder.Entity<Material>(entity =>
            {
                entity.HasKey(e => e.IdMaterial);

                entity.ToTable("Material");

                entity.HasIndex(e => e.TitleOfMaterial, "UQ_Title_Of_Material")
                    .IsUnique();

                entity.Property(e => e.IdMaterial).HasColumnName("ID_Material");

                entity.Property(e => e.TitleOfMaterial)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Title_Of_Material");
            });

            modelBuilder.Entity<Motorcycle>(entity =>
            {
                entity.HasKey(e => e.IdMotorcycle);

                entity.ToTable("Motorcycle");

                entity.HasIndex(e => e.TitleMotorcycle, "UQ_Title_Motorcycle")
                    .IsUnique();

                entity.Property(e => e.IdMotorcycle).HasColumnName("ID_Motorcycle");

                entity.Property(e => e.ArticleNumber)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("Article_Number");

                entity.Property(e => e.ColorId).HasColumnName("Color_ID");

                entity.Property(e => e.EngineCapacityId).HasColumnName("Engine_Capacity_ID");

                entity.Property(e => e.MotorcycleBrandId).HasColumnName("Motorcycle_Brand_ID");

                entity.Property(e => e.PictureOfMotorcycle).HasColumnName("Picture_Of_Motorcycle");

                entity.Property(e => e.TitleMotorcycle)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Title_Motorcycle");

                entity.Property(e => e.YearOfRealese)
                    .HasColumnType("date")
                    .HasColumnName("Year_Of_Realese");

                entity.HasOne(d => d.Color)
                    .WithMany(p => p.Motorcycles)
                    .HasForeignKey(d => d.ColorId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Color");

                entity.HasOne(d => d.EngineCapacity)
                    .WithMany(p => p.Motorcycles)
                    .HasForeignKey(d => d.EngineCapacityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Engine_Capacity");

                entity.HasOne(d => d.MotorcycleBrand)
                    .WithMany(p => p.Motorcycles)
                    .HasForeignKey(d => d.MotorcycleBrandId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Motorcycle_Brand");
            });

            modelBuilder.Entity<MotorcycleBrand>(entity =>
            {
                entity.HasKey(e => e.IdMotorcycleBrand);

                entity.ToTable("Motorcycle_Brand");

                entity.HasIndex(e => e.TitleMotorcycleBrand, "UQ_Title_Motorcycle_Brand")
                    .IsUnique();

                entity.Property(e => e.IdMotorcycleBrand).HasColumnName("ID_Motorcycle_Brand");

                entity.Property(e => e.TitleMotorcycleBrand)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Title_Motorcycle_Brand");
            });

            modelBuilder.Entity<MotorcycleEquipment>(entity =>
            {
                entity.HasKey(e => e.IdMotorcycleEquipment);

                entity.ToTable("Motorcycle_Equipment");

                entity.Property(e => e.IdMotorcycleEquipment).HasColumnName("ID_Motorcycle_Equipment");

                entity.Property(e => e.MaterialId).HasColumnName("Material_ID");

                entity.Property(e => e.PictureOfMotorcycleEquipment).HasColumnName("Picture_Of_Motorcycle_Equipment");

                entity.Property(e => e.TitleEquipment)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Title_Equipment");

                entity.Property(e => e.TypeMotorcycleEquipmentId).HasColumnName("Type_Motorcycle_Equipment_ID");

                entity.HasOne(d => d.Material)
                    .WithMany(p => p.MotorcycleEquipments)
                    .HasForeignKey(d => d.MaterialId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Material");

                entity.HasOne(d => d.TypeMotorcycleEquipment)
                    .WithMany(p => p.MotorcycleEquipments)
                    .HasForeignKey(d => d.TypeMotorcycleEquipmentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Type_Motorcycle_Equipment");
            });

            modelBuilder.Entity<Order>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Order");

                entity.Property(e => e.ClientId).HasColumnName("Client_ID");

                entity.Property(e => e.IdOrder)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("ID_Order");

                entity.Property(e => e.MotorcycleId).HasColumnName("Motorcycle_ID");

                entity.Property(e => e.PartId).HasColumnName("Part_ID");

                entity.HasOne(d => d.Client)
                    .WithMany()
                    .HasForeignKey(d => d.ClientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Client");

                entity.HasOne(d => d.Motorcycle)
                    .WithMany()
                    .HasForeignKey(d => d.MotorcycleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Motorcycle");

                entity.HasOne(d => d.Part)
                    .WithMany()
                    .HasForeignKey(d => d.PartId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Part");
            });

            modelBuilder.Entity<Part>(entity =>
            {
                entity.HasKey(e => e.IdPart);

                entity.ToTable("Part");

                entity.Property(e => e.IdPart).HasColumnName("ID_Part");

                entity.Property(e => e.MaterialId).HasColumnName("Material_ID");

                entity.Property(e => e.PictureOfPart).HasColumnName("Picture_Of_Part");

                entity.Property(e => e.TitlePart)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Title_Part");

                entity.Property(e => e.TypePartId).HasColumnName("Type_Part_ID");

                entity.HasOne(d => d.Material)
                    .WithMany(p => p.Parts)
                    .HasForeignKey(d => d.MaterialId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Part_Material");

                entity.HasOne(d => d.TypePart)
                    .WithMany(p => p.Parts)
                    .HasForeignKey(d => d.TypePartId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Type_Part");
            });

            modelBuilder.Entity<TypeMotorcycleEquipment>(entity =>
            {
                entity.HasKey(e => e.IdTypeMotorcycleEquipment);

                entity.ToTable("Type_Motorcycle_Equipment");

                entity.HasIndex(e => e.TitleTypeMotorcycleEquipment, "UQ_Title_Motorcycle_Equipment")
                    .IsUnique();

                entity.Property(e => e.IdTypeMotorcycleEquipment).HasColumnName("ID_Type_Motorcycle_Equipment");

                entity.Property(e => e.TitleTypeMotorcycleEquipment)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Title_Type_Motorcycle_Equipment");
            });

            modelBuilder.Entity<TypePart>(entity =>
            {
                entity.HasKey(e => e.IdTypePart);

                entity.ToTable("Type_Part");

                entity.HasIndex(e => e.TitleTypePart, "UQ_Title_Type_Part")
                    .IsUnique();

                entity.Property(e => e.IdTypePart).HasColumnName("ID_Type_Part");

                entity.Property(e => e.TitleTypePart)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("Title_Type_Part");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
