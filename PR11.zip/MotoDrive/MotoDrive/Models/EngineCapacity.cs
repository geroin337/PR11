﻿using System;
using System.Collections.Generic;

namespace MotoDrive.Models
{
    public partial class EngineCapacity
    {
        public EngineCapacity()
        {
            Motorcycles = new HashSet<Motorcycle>();
        }

        public int IdEngineCapacity { get; set; }
        public string EngineCapacity1 { get; set; } = null!;

        public virtual ICollection<Motorcycle> Motorcycles { get; set; }
    }
}
