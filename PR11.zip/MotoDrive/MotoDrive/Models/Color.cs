﻿using System;
using System.Collections.Generic;

namespace MotoDrive.Models
{
    public partial class Color
    {
        public Color()
        {
            Motorcycles = new HashSet<Motorcycle>();
        }

        public int IdColor { get; set; }
        public string TitleColor { get; set; } = null!;

        public virtual ICollection<Motorcycle> Motorcycles { get; set; }
    }
}
