﻿using System;
using System.Collections.Generic;

namespace MotoDrive.Models
{
    public partial class Motorcycle
    {
        public int IdMotorcycle { get; set; }
        public int Price { get; set; }
        public int ColorId { get; set; }
        public int EngineCapacityId { get; set; }
        public int MotorcycleBrandId { get; set; }
        public DateTime YearOfRealese { get; set; }
        public string ArticleNumber { get; set; } = null!;
        public byte[]? PictureOfMotorcycle { get; set; }
        public string TitleMotorcycle { get; set; } = null!;

        public virtual Color Color { get; set; } = null!;
        public virtual EngineCapacity EngineCapacity { get; set; } = null!;
        public virtual MotorcycleBrand MotorcycleBrand { get; set; } = null!;
    }
}
