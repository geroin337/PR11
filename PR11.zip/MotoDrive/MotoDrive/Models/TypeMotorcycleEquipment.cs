﻿using System;
using System.Collections.Generic;

namespace MotoDrive.Models
{
    public partial class TypeMotorcycleEquipment
    {
        public TypeMotorcycleEquipment()
        {
            MotorcycleEquipments = new HashSet<MotorcycleEquipment>();
        }

        public int IdTypeMotorcycleEquipment { get; set; }
        public string TitleTypeMotorcycleEquipment { get; set; } = null!;

        public virtual ICollection<MotorcycleEquipment> MotorcycleEquipments { get; set; }
    }
}
