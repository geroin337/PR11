﻿using System;
using System.Collections.Generic;

namespace MotoDrive.Models
{
    public partial class TypePart
    {
        public TypePart()
        {
            Parts = new HashSet<Part>();
        }

        public int IdTypePart { get; set; }
        public string TitleTypePart { get; set; } = null!;

        public virtual ICollection<Part> Parts { get; set; }
    }
}
