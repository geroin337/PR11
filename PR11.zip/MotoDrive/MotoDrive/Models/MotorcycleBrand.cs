﻿using System;
using System.Collections.Generic;

namespace MotoDrive.Models
{
    public partial class MotorcycleBrand
    {
        public MotorcycleBrand()
        {
            Motorcycles = new HashSet<Motorcycle>();
        }

        public int IdMotorcycleBrand { get; set; }
        public string TitleMotorcycleBrand { get; set; } = null!;

        public virtual ICollection<Motorcycle> Motorcycles { get; set; }
    }
}
