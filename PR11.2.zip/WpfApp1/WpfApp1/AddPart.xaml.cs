﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Model;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для AddPart.xaml
    /// </summary>
    public partial class AddPart : Window
    {
        public AddPart()
        {
            InitializeComponent();
            Id1.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Material.ToList();
            Id2.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Type_Part.ToList();
            WindowState = WindowState.Maximized;
            WindowStyle = WindowStyle.None;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.ShowDialog();
                byte[] image_bytes = File.ReadAllBytes(openFileDialog.FileName);

                using (SqlConnection connection = new SqlConnection(DataBaseClass.ConnectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand();
                    command.Connection = connection;
                    command.CommandText = $"insert into [dbo].[Part] ([Price], [Material_ID], [Type_Part_ID], [Title_Part], [Picture_Of_Part]) values  ({Price.Text}, {Id1.SelectedValue}, {Id2.SelectedValue}, '{Title_Part.Text}', @ImageData)";
                    command.Parameters.Add("@ImageData", SqlDbType.Image, 1000000);
                    command.Parameters["@ImageData"].Value = image_bytes;
                    command.ExecuteNonQuery();

                }
            }

            catch
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Part inf = new Part();
            inf.Show();
            this.Close();
        }
    }
}
