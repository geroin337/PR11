﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Model;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для EditingMotorcycle.xaml
    /// </summary>
    public partial class EditingMotorcycle : Window
    {
        public Moto_Drive_DatabaseEntities2 baseModel = new Moto_Drive_DatabaseEntities2();
        public EditingMotorcycle(Motorcycle selectProduct)

        {
            InitializeComponent();
            WindowState = WindowState.Maximized;
            WindowStyle = WindowStyle.None;
            Id.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Motorcycle_Brand.ToList();
            Id2.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Color.ToList();
            Id3.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Engine_Capacity.ToList();
            getMotorcycle();
        }

        public void getMotorcycle()
        {

            DgridBooking.ItemsSource = null;
            DgridBooking.ItemsSource = baseModel.Motorcycle.ToList();
        }

        private void BtnEdit(object sender, RoutedEventArgs e)
        {
            {

                Motorcycle selectedProduct = DgridBooking.SelectedItem as Motorcycle;

                if (selectedProduct != null)
                {

                    string newValue1 = Price.Text;
                    string newValue2 = Year_Of_Realese.Text;
                    string newValue3 = Article_Number.Text;
                    string newValue4 = Id.SelectedValue.ToString();
                    string newValue5 = Id2.SelectedValue.ToString();
                    string newValue6 = Id3.SelectedValue.ToString();
                    string newValue7 = Title_Motorcycle.Text;





                    selectedProduct.Price = int.Parse(newValue1);
                    selectedProduct.Year_Of_Realese = DateTime.Parse(newValue2);
                    selectedProduct.Article_Number = (newValue3);
                    selectedProduct.Motorcycle_Brand_ID = int.Parse(newValue4);
                    selectedProduct.Color_ID = int.Parse(newValue5);
                    selectedProduct.Engine_Capacity_ID = int.Parse(newValue6);
                    selectedProduct.Title_Motorcycle = (newValue7);






                    try
                    {
                        Moto_Drive_DatabaseEntities2.GetContext().SaveChanges();
                        MessageBox.Show("Данные обновлены");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }


                    DgridBooking.ItemsSource = null;
                    DgridBooking.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Motorcycle.ToList();
                }
                else
                {
                    MessageBox.Show("Выберите элемент для редактирования.");
                }
            }
        }

        private void BtnBack(object sender, RoutedEventArgs e)
        {
            Moto inf = new Moto();
            inf.Show();
            this.Close();
        }

        

        private void DgridBooking_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Motorcycle selectedProduct = DgridBooking.SelectedItem as Motorcycle;
            if (DgridBooking.SelectedItems.Count > 0)
            {
                Price.Text = selectedProduct.Price.ToString();
                Year_Of_Realese.Text = selectedProduct.Year_Of_Realese.ToString();
                Article_Number.Text = selectedProduct.Article_Number.ToString();
                Title_Motorcycle.Text = selectedProduct.Title_Motorcycle.ToString();
                Id.Text = selectedProduct.Motorcycle_Brand.Title_Motorcycle_Brand.ToString();
                Id2.Text = selectedProduct.Color.Title_Color.ToString();
                Id3.Text = selectedProduct.Engine_Capacity.Engine_Capacity1.ToString();
            }

        }
    }
}
