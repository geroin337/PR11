﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Model;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для AddEquipment.xaml
    /// </summary>
    public partial class AddEquipment : Window
    {
        public AddEquipment()
        {
            InitializeComponent();
            Id1.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Material.ToList();
            Id2.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Type_Motorcycle_Equipment.ToList();
            WindowState = WindowState.Maximized;
            WindowStyle = WindowStyle.None;
        }

        private void BtnAdd(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.ShowDialog();
                byte[] image_bytes = File.ReadAllBytes(openFileDialog.FileName);

                using (SqlConnection connection = new SqlConnection(DataBaseClass.ConnectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand();
                    command.Connection = connection;
                    command.CommandText = $"insert into [dbo].[Motorcycle_Equipment] ([Price], [Material_ID], [Type_Motorcycle_Equipment_ID], [Title_Equipment], [Picture_Of_Motorcycle_Equipment]) values  ({Price.Text}, {Id1.SelectedValue}, {Id2.SelectedValue}, '{Title_Equipment.Text}', @ImageData)";
                    command.Parameters.Add("@ImageData", SqlDbType.Image, 1000000);
                    command.Parameters["@ImageData"].Value = image_bytes;
                    command.ExecuteNonQuery();

                }
            }

            catch
            {
                MessageBox.Show("Ошибка");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Equipment inf = new Equipment();
            inf.Show();
            this.Close();
        }
    }
}
