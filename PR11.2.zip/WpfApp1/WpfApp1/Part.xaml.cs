﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Model;


namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Part.xaml
    /// </summary>
    public partial class Part : Window
    {
        public Part()
        {
            InitializeComponent();
            DgridPart.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Part.ToList();
            WindowState = WindowState.Maximized;
            WindowStyle = WindowStyle.None;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddPart addPart = new AddPart();
            addPart.Show();
            this.Close();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            EditingPart edi = new EditingPart((sender as Button).DataContext as Part);
            edi.Show();
            this.Close();
        }

        private void BtnDell_Click(object sender, RoutedEventArgs e)
        {

            var productsForRemoving = DgridPart.SelectedItems.Cast<WpfApp1.Model.Part>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующие {productsForRemoving.Count} элементов?",
                "Внимание",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                var context = Moto_Drive_DatabaseEntities2.GetContext();
                context.Part.RemoveRange(productsForRemoving);

                context.SaveChanges();

                MessageBox.Show("Данные удалены");

                DgridPart.ItemsSource = context.Part.ToList();
            }
            catch (Exception ex)
            {
                var message = ex.Message;
                if (ex.InnerException != null)
                {
                    message += $": {ex.InnerException.Message}";
                }

                MessageBox.Show(message);
            }
        }





        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchValue = TxtSearch.Text;
            SearchInDataGrid(searchValue);
        }

        private void SearchInDataGrid(string searchValue)
        {
            ICollectionView collectionView = CollectionViewSource.GetDefaultView(DgridPart.ItemsSource);

            if (collectionView != null)
            {
                if (!string.IsNullOrEmpty(searchValue))
                {
                    // Filtering data using LINQ
                    collectionView.Filter = item =>
                    {
                        if (item is WpfApp1.Model.Part part)
                        {
                            // Replace Type_Part with the actual property you want to search
                            return part.Type_Part.Title_Type_Part
                                .IndexOf(searchValue, StringComparison.OrdinalIgnoreCase) >= 0;
                        }
                        return false;
                    };
                }
                else
                {
                    // If the search string is empty, reset the filter
                    collectionView.Filter = null;
                }
            }
        }



        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Moto moto = new Moto();
            moto.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Equipment equipment = new Equipment();
            equipment.Show();
            this.Close();
        }
    }
}
