﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Model;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для EditingPart.xaml
    /// </summary>
    public partial class EditingPart : Window

    {
        public Moto_Drive_DatabaseEntities2 baseModel = new Moto_Drive_DatabaseEntities2();


        public EditingPart(Part selectProduct)
        {
            InitializeComponent();
            Id1.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Material.ToList();
            Id2.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Type_Part.ToList();
            WindowState = WindowState.Maximized;
            WindowStyle = WindowStyle.None;
            getPart();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            {

                Model.Part selectedProduct = DgridBooking.SelectedItem as Model.Part;

                if (selectedProduct != null)
                {

                    string newValue1 = Price.Text;
                    string newValue2 = Id1.SelectedValue.ToString();
                    string newValue3 = Id2.SelectedValue.ToString();
                    string newValue4 = Title_Part.Text;





                    selectedProduct.Price = int.Parse(newValue1);
                    selectedProduct.Material_ID = int.Parse(newValue2);
                    selectedProduct.Type_Part_ID = int.Parse(newValue3);
                    selectedProduct.Title_Part = (newValue4);






                    try
                    {
                        Moto_Drive_DatabaseEntities2.GetContext().SaveChanges();
                        MessageBox.Show("Данные обновлены");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }


                    DgridBooking.ItemsSource = null;
                    DgridBooking.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Part.ToList();
                }
                else
                {
                    MessageBox.Show("Выберите элемент для редактирования.");
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Part inf = new Part();
            inf.Show();
            this.Close();
        }

        private void DgridBooking_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Model.Part selectedProduct = DgridBooking.SelectedItem as Model.Part;
            if (DgridBooking.SelectedItems.Count > 0)
            {
                Price.Text = selectedProduct.Price.ToString();
                Id1.Text = selectedProduct.Material.Title_Of_Material.ToString();
                Id2.Text = selectedProduct.Type_Part.Title_Type_Part.ToString();
                Title_Part.Text = selectedProduct.Title_Part.ToString();

            }
        }
        public void getPart()
        {

            DgridBooking.ItemsSource = null;
            DgridBooking.ItemsSource = baseModel.Part.ToList();
        }
    }
}
