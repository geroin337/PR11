﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Model;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для CSV.xaml
    /// </summary>
    public partial class CSV : Window
    {
        public CSV()
        {
            InitializeComponent();
            DgridBooking.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Motorcycle.ToList();
            WindowState = WindowState.Maximized;
            WindowStyle = WindowStyle.None;
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Moto inf = new Moto();
            inf.Show();
            this.Close();
        }

        private void BtnExportToCSV_Click(object sender, RoutedEventArgs e)
        {
            List<Motorcycle> motorcycle = DgridBooking.ItemsSource.Cast<Motorcycle>().ToList();
            ExportToCSV(motorcycle);
        }
        private void ExportToCSV(List<Motorcycle> motorcycle)
        {
            var csvPath = "path_to_csv_file.csv";

            using (var writer = new StreamWriter(csvPath))
            using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
            {
                csv.WriteRecords(motorcycle);
            }

            MessageBox.Show("Данные экспортированы в CSV файл");
        }
    }
}
