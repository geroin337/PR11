﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Model;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для EditingEquipment.xaml
    /// </summary>
    public partial class EditingEquipment : Window
    {
        public Moto_Drive_DatabaseEntities2 baseModel = new Moto_Drive_DatabaseEntities2();
        

        public EditingEquipment(Equipment selectProduct)


        {
            InitializeComponent();
            Id1.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Material.ToList();
            Id2.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Type_Motorcycle_Equipment.ToList();
            WindowState = WindowState.Maximized;
            WindowStyle = WindowStyle.None;
            getMotorcycle_Equipment();
        }

        private void DgridBooking_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Motorcycle_Equipment selectedProduct = DgridBooking.SelectedItem as Motorcycle_Equipment;
            if (DgridBooking.SelectedItems.Count > 0)
            {
                Price.Text = selectedProduct.Price.ToString();
                Id1.Text = selectedProduct.Material.Title_Of_Material.ToString();
                Id2.Text = selectedProduct.Type_Motorcycle_Equipment.Title_Type_Motorcycle_Equipment.ToString();
                Title_Equipment.Text = selectedProduct.Title_Equipment.ToString();

            }
        }
        public void getMotorcycle_Equipment()
        {

            DgridBooking.ItemsSource = null;
            DgridBooking.ItemsSource = baseModel.Motorcycle_Equipment.ToList();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            {

                Motorcycle_Equipment selectedProduct = DgridBooking.SelectedItem as Motorcycle_Equipment;

                if (selectedProduct != null)
                {

                    string newValue1 = Price.Text;
                    string newValue2 = Id1.SelectedValue.ToString();
                    string newValue3 = Id2.SelectedValue.ToString();
                    string newValue4 = Title_Equipment.Text;





                    selectedProduct.Price = int.Parse(newValue1);
                    selectedProduct.Material_ID = int.Parse(newValue2);
                    selectedProduct.Type_Motorcycle_Equipment_ID = int.Parse(newValue3);
                    selectedProduct.Title_Equipment = (newValue4);






                    try
                    {
                        Moto_Drive_DatabaseEntities2.GetContext().SaveChanges();
                        MessageBox.Show("Данные обновлены");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }


                    DgridBooking.ItemsSource = null;
                    DgridBooking.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Motorcycle_Equipment.ToList();
                }
                else
                {
                    MessageBox.Show("Выберите элемент для редактирования.");
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Equipment inf = new Equipment();
            inf.Show();
            this.Close();
        }
    }

}