﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Model;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Moto.xaml
    /// </summary>
    public partial class Moto : Window
    {
        public Moto()
        {
            InitializeComponent();
            DgridMotorcycle.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Motorcycle.ToList();
            WindowState = WindowState.Maximized;
            WindowStyle = WindowStyle.None;
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            string searchValue = TxtSearch.Text;
            SearchInDataGrid(searchValue);
        }

        private void SearchInDataGrid(string searchValue)
        {
            ICollectionView collectionView = CollectionViewSource.GetDefaultView(DgridMotorcycle.ItemsSource);

            if (collectionView != null)
            {
                if (!string.IsNullOrEmpty(searchValue))
                {
                    collectionView.Filter = item =>
                    {
                        if (item is Motorcycle motorcycle)
                        {
                            return motorcycle.Motorcycle_Brand.Title_Motorcycle_Brand
                                .IndexOf(searchValue, StringComparison.OrdinalIgnoreCase) >= 0;
                        }
                        return false;
                    };
                }
                else
                {
                    collectionView.Filter = null;
                }
            }
        }




        private bool IsInputValid(string searchValue, out int searchIntValue)
        {
            throw new NotImplementedException();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string filterColor = "Черный"; 
            ApplyColorFilter(filterColor);
        }

        private void ApplyColorFilter(string filterColor)
        {
            ICollectionView collectionView = CollectionViewSource.GetDefaultView(DgridMotorcycle.ItemsSource);

            if (collectionView != null)
            {
                if (!string.IsNullOrEmpty(filterColor))
                {
                    collectionView.Filter = item =>
                    {
                        if (item is Motorcycle motorcycle)
                        {
                            return motorcycle.Color.Title_Color
                                .IndexOf(filterColor, StringComparison.OrdinalIgnoreCase) >= 0;
                        }
                        return false;
                    };
                }
                else
                {
                    collectionView.Filter = null;
                }
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddMotorcycle addMotorcycle = new AddMotorcycle ();
            addMotorcycle.Show();
            this.Close();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            EditingMotorcycle edi = new EditingMotorcycle((sender as Button).DataContext as Motorcycle);
            edi.Show();
            this.Close();
        }

        private void BtnDell_Click(object sender, RoutedEventArgs e)
        {
            var productsForRemoving = DgridMotorcycle.SelectedItems.Cast<Motorcycle>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить следующие {productsForRemoving.Count} элементов?",
                "Внимание",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                var context = Moto_Drive_DatabaseEntities2.GetContext();

                context.Motorcycle.RemoveRange(productsForRemoving);
                context.SaveChanges();

                MessageBox.Show("Данные удалены");

                DgridMotorcycle.ItemsSource = context.Motorcycle.ToList();
            }
            catch (Exception ex)
            {
                var message = ex.Message;
                if (ex.InnerException != null)
                {
                    message += $": {ex.InnerException.Message}";
                }

                MessageBox.Show(message);
            }
        }

        private void CSV_Click(object sender, RoutedEventArgs e)
        {
            CSV csv = new CSV();
            csv.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Equipment equipment = new Equipment();
            equipment.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Part part = new Part();
            part.Show();
            this.Close();
        }

    }
}
