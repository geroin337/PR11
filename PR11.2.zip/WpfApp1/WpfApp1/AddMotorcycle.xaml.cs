﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Model;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для AddMotorcycle.xaml
    /// </summary>
    public partial class AddMotorcycle : Window
    {
        public AddMotorcycle()
        {
            InitializeComponent();
            Id.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Motorcycle_Brand.ToList();
            Id2.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Color.ToList();
            Id3.ItemsSource = Moto_Drive_DatabaseEntities2.GetContext().Engine_Capacity.ToList();
            WindowState = WindowState.Maximized;
            WindowStyle = WindowStyle.None;
        }
        private void BtnAdd(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.ShowDialog();
                byte[] image_bytes = File.ReadAllBytes(openFileDialog.FileName);

                using (SqlConnection connection = new SqlConnection(DataBaseClass.ConnectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand();
                    command.Connection = connection;
                    command.CommandText = $"insert into [dbo].[Motorcycle] ([Price], [Color_ID], [Engine_Capacity_ID], [Motorcycle_Brand_ID], [Year_Of_Realese], [Article_Number], [Title_Motorcycle], [Picture_Of_Motorcycle]) values  ({Price.Text}, {Id2.SelectedValue}, {Id3.SelectedValue},{Id.SelectedValue}, '{Year_Of_Realese.Text}', '{Article_Number.Text}', '{Title_Motorcycle.Text}', @ImageData)";
                    command.Parameters.Add("@ImageData", SqlDbType.Image, 1000000);
                    command.Parameters["@ImageData"].Value = image_bytes;
                    command.ExecuteNonQuery();

                }
            }

            catch
            {
                MessageBox.Show("Ошибка");
            }
        }
        private void BtnBack(object sender, RoutedEventArgs e)
        {
            Moto inf = new Moto();
            inf.Show();
            this.Close();
        }

        private void Title_Motorcycle_TextChanged(object sender, TextChangedEventArgs e)
        {

        }


    }
}

