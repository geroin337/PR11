set ansi_padding on
go
set ansi_nulls on
go
set quoted_identifier on
go
create database [Moto_Drive_Database]
go
use [Moto_Drive_Database]
go

create table [dbo].[Color]
(
[ID_Color] [int] not null identity(1,1),
[Title_Color] [varchar] (50) not null
constraint [PK_Color] primary key clustered
([ID_Color] ASC) on [PRIMARY],
constraint [UQ_Title_Color] unique
([Title_Color])
)
go
insert into [dbo].[Color] ([Title_Color])
values ('����������'),
('������'),
('�����'),
('�������'),
('�����'),
('����������')

create table [dbo].[Motorcycle_Brand]
(
[ID_Motorcycle_Brand] [int] not null identity(1,1),
[Title_Motorcycle_Brand] [varchar] (50) not null
constraint [PK_Motorcycle_Brand] primary key clustered
([ID_Motorcycle_Brand] ASC) on [PRIMARY],
constraint [UQ_Title_Motorcycle_Brand] unique
([Title_Motorcycle_Brand])
)
go
insert into [dbo].[Motorcycle_Brand] ([Title_Motorcycle_Brand])
values ('Honda'),
('Ducati'),
('BigDog'),
('Aprillia'),
('BMW'),
('Kawasaki'),
('Yamaha'),
('Harley-Davidson')

create table [dbo].[Engine_Capacity]
(
[ID_Engine_Capacity] [int] not null identity(1,1),
[Engine_Capacity] [varchar] (4) not null
constraint [PK_Engine_Capacity] primary key clustered
([ID_Engine_Capacity] ASC) on [PRIMARY],
constraint [UQ_Engine_Capacity] unique
([Engine_Capacity]),
constraint [CH_Engine_Capacity] check
([Engine_Capacity] like ('%[0-9]%'))
)
go
insert into [dbo].[Engine_Capacity] ([Engine_Capacity])
values ('650'),
('700'),
('750'),
('400'),
('350'),
('600')

create table [dbo].[Type_Part]
(
[ID_Type_Part] [int] not null identity(1,1),
[Title_Type_Part] [varchar] (50) not null
constraint [PK_Type_Part] primary key clustered
([ID_Type_Part] ASC) on [PRIMARY],
constraint [UQ_Title_Type_Part] unique
([Title_Type_Part])
)
go
insert into [dbo].[Type_Part] ([Title_Type_Part])
values('����������'),
('����'),
('�����������'),
('��������� �������'),
('���������'),
('��������')

create table [dbo].[Material]
(
[ID_Material] [int] not null identity(1,1),
[Title_Of_Material] [varchar] (50) not null
constraint [PK_Material] primary key clustered
([ID_Material] ASC) on [PRIMARY],
constraint [UQ_Title_Of_Material] unique
([Title_Of_Material])
)
go
insert into [dbo].[Material]([Title_Of_Material])
values ('����'),
('������������ C405')

create table [dbo].[Type_Motorcycle_Equipment]
(
[ID_Type_Motorcycle_Equipment] [int] not null identity(1,1),
[Title_Type_Motorcycle_Equipment] [varchar] (50) not null
constraint [PK_Type_Motorcycle_Equipment] primary key clustered
([ID_Type_Motorcycle_Equipment] ASC) on [PRIMARY],
constraint [UQ_Title_Motorcycle_Equipment] unique
([Title_Type_Motorcycle_Equipment])
)
go
insert into [dbo].[Type_Motorcycle_Equipment] ([Title_Type_Motorcycle_Equipment])
values('���������'),
('����������'),
('���������������'),
('������������'),
('�����������'),
('�������')

alter table [dbo].[Motorcycle_Equipment] add constraint [UQ_Title_Equipment] unique ([Title_Equipment])

create table [dbo].[Motorcycle_Equipment]
(
[ID_Motorcycle_Equipment] [int] not null identity(1,1),
[Price] [int] not null,
[Material_ID] [int] not null,
[Type_Motorcycle_Equipment_ID] [int] not null,
[Picture_Of_Motorcycle_Equipment] [varbinary] (max) not null,
[Title_Equipment] [varchar] (50) not null
constraint [PK_Motorcycle_Equipment] primary key clustered
([ID_Motorcycle_Equipment] ASC) on [PRIMARY],
constraint [FK_Material] foreign key
([Material_ID]) references [dbo].[Material] ([ID_Material]),
constraint [FK_Type_Motorcycle_Equipment] foreign key
([Type_Motorcycle_Equipment_ID]) references [dbo].[Type_Motorcycle_Equipment] ([ID_Type_Motorcycle_Equipment])
)
go
insert into [dbo].[Motorcycle_Equipment] ([Price], [Material_ID], [Type_Motorcycle_Equipment_ID], [Picture_Of_Motorcycle_Equipment], [Title_Equipment])
values (10000, 2, 6, (select * from openrowset(bulk 'C:\Sait\s6.png', single_blob)as image), '100 Acuri')

select * from [dbo].[Type_Motorcycle_Equipment]

alter table [dbo].[Part] add constraint [UQ_Title_Part] unique ([Title_Part])

create table [dbo].[Part]
(
[ID_Part] [int] not null identity(1,1),
[Price] [int] not null,
[Material_ID] [int] not null,
[Type_Part_ID] [int] not null,
[Picture_Of_Part] [varbinary] (max) not null,
[Title_Part] [varchar] (50) not null
constraint [PK_Part] primary key clustered
([ID_Part] ASC) on [PRIMARY],
constraint [FK_Part_Material] foreign key
([Material_ID]) references [dbo].[Material] ([ID_Material]),
constraint [FK_Type_Part] foreign key
([Type_Part_ID]) references [dbo].[Type_Part] ([ID_Type_Part])
)
go
insert into [dbo].[Part] ([Price], [Material_ID], [Type_Part_ID], [Picture_Of_Part], [Title_Part])
values (17000, 2, 3, (select * from openrowset(bulk 'C:\Sait\r2.jpg', single_blob)as image), '�����������')

create table [dbo].[Motorcycle]
(
[ID_Motorcycle] [int] not null identity(1,1),
[Price] [int] not null,
[Color_ID] [int] not null,
[Engine_Capacity_ID] [int] not null,
[Motorcycle_Brand_ID] [int] not null,
[Year_Of_Realese] [date] not null,
[Article_Number] [varchar] (6) not null,
[Picture_Of_Motorcycle] [varbinary] (max) null,
[Title_Motorcycle] [varchar] (50) not null
constraint [PK_Motorcycle] primary key clustered
([ID_Motorcycle] ASC) on [PRIMARY],
constraint [CH_Article_Number] check
([Article_Number] like ('%[0-9]%')),
constraint [UQ_Title_Motorcycle] unique
([Title_Motorcycle]),
constraint [FK_Color] foreign key
([Color_ID]) references [dbo].[Color] ([ID_Color]),
constraint [FK_Engine_Capacity] foreign key
([Engine_Capacity_ID]) references [dbo].[Engine_Capacity] ([ID_Engine_Capacity]),
constraint [FK_Motorcycle_Brand] foreign key
([Motorcycle_Brand_ID]) references [dbo].[Motorcycle_Brand] ([ID_Motorcycle_Brand]),
)
go

insert into [dbo].[Motorcycle] ([Price], [Color_ID], [Engine_Capacity_ID], [Motorcycle_Brand_ID], [Year_Of_Realese], [Article_Number], [Title_Motorcycle])
values (1000000, 2, 3, 8, '10.09.2022', 'QWW126', 'STREET')

update [dbo].[Motorcycle]
set [Picture_Of_Motorcycle] = (select * from openrowset(bulk 'C:\Sait\HF.png', single_blob)as image)
where [ID_Motorcycle] = 6

delete from [dbo].[Motorcycle] where [ID_Motorcycle] = 1
select * from [dbo].[Motorcycle]
select * from [dbo].[Engine_Capacity]
select * from [dbo].[Color]
select * from [dbo].[Motorcycle_Brand]

create table [dbo].[Client]
(
[ID_Client] [int] not null identity(1,1),
[Login] [varchar] (30) not null,
[E-mail] [varchar] (50) not null,
[Password] [varchar] (30) not null,
[Role_ID] [int] not null,
constraint [PK_Client] primary key clustered
([ID_Client] ASC) on [PRIMARY],
constraint [CH_Login] check
(len([Login])>=8),
constraint [CH_Password_Upper] check
([Password] like ('%[A-Z]%')),
constraint [CH_Password_Lower] check
([Password] like ('%[a-z]%')),
constraint [CH_Password_Symbwols] check
([Password] like ('%[!#$><|?)(_-+=&*%^@{}"":;.,]%')),
constraint [CH_Password_Numbers] check
([Password] like ('%[0-9]%')),
constraint [CH_E-mail_Dot] check
([E-mail] like ('%[.]%')),
constraint [CH_E-mail_Sob] check
([E-mail] like ('%[@]%'))
)
go

select * from [dbo].[Admin]

create table [dbo].[Order]
(
[ID_Order] [int] not null identity(1,1),
[Motorcycle_ID] [int] not null,
[Part_ID] [int] not null,
[Client_ID] [int] not null,
[Motorcycle_Equipment_ID] [int] not null
constraint [FK_Motorcycle] foreign key
([Motorcycle_ID]) references [dbo].[Motorcycle] ([ID_Motorcycle]),
constraint [FK_Part] foreign key
([Part_ID]) references [dbo].[Part] ([ID_Part]),
constraint [FK_Client] foreign key
([Client_ID]) references [dbo].[Client] ([ID_Client]),
constraint [FK_Motorcycle_Equipment] foreign key
([Motorcycle_Equipment_ID]) references [dbo].[Motorcycle_Equipment] ([ID_Motorcycle_Equipment])
)
go
select * from [dbo].[Order]
insert into [dbo].[Order]
values(1, 1, 5, 4)

create table [dbo].[Role]
(
[ID_Role] [int] not null identity(1,1),
[Name_Role] [varchar] (6) not null,
)
go
create table [dbo].[Admin]
(
[ID_Admin] [int] not null identity(1,1),
[Login_Admin] [varchar] (6) not null,
[Password_Admin] [varchar] (6) not null,
[Role_ID] [int] not null,
)
go
insert into [dbo].[Admin] ([Login_Admin], [Password_Admin])
values ('papa12', '123pap')
go


create view [dbo].[vw_Color]
as
select [ID_Color], [Title_Color]
from [dbo].[Color]
go

create view [dbo].[vw_Motorcycle_Brand]
as
select [ID_Motorcycle_Brand], [Title_Motorcycle_Brand]
from [dbo].[Motorcycle_Brand]
go

create view [dbo].[vw_Engine_Capacity]
as
select [ID_Engine_Capacity], [Engine_Capacity]
from [dbo].[Engine_Capacity]
go

CREATE PROCEDURE dbo.InsertOrder
    @MotorcycleID INT,
    @PartID INT,
    @ClientID INT,
    @EquipmentID INT
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.[Order] (Motorcycle_ID, Part_ID, Client_ID, Motorcycle_Equipment_ID)
    VALUES (@MotorcycleID, @PartID, @ClientID, @EquipmentID);
END;

 CREATE FUNCTION dbo.GetOrderCountByClient
    (@ClientID INT)
RETURNS INT
AS
BEGIN
    DECLARE @OrderCount INT;

    SELECT @OrderCount = COUNT(ID_Order)
    FROM dbo.[Order]
    WHERE Client_ID = @ClientID;

    RETURN @OrderCount;
END;

CREATE TRIGGER tr_CheckUniqueArticleNumber
ON [dbo].[Motorcycle]
INSTEAD OF INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM [dbo].[Motorcycle] m
        JOIN inserted i ON m.Article_Number = i.Article_Number
    )
    BEGIN
        RAISEERROR ('�������� � ����� ��������� ��� ����'16, 1);
    END
    ELSE
    BEGIN
        INSERT INTO [dbo].[Motorcycle]
        SELECT * FROM inserted;
    END
END;

CREATE TRIGGER tr_CheckUniqueTitlePart
ON [dbo].[Part]
INSTEAD OF INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM [dbo].[Part] p
        JOIN inserted i ON p.Title_Part = i.Title_Part
    )
    BEGIN
        RAISEERROR ('������ � ����� ��������� ��� ����', 16, 1);
    END
    ELSE
    BEGIN
        INSERT INTO [dbo].[Part]
        SELECT * FROM inserted;
    END
END;

CREATE TRIGGER tr_CheckUniqueTitleEquipment
ON [dbo].[Motorcycle_Equipment]
INSTEAD OF INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM [dbo].[Motorcycle_Equipment] me
        JOIN inserted i ON me.Title_Equipment = i.Title_Equipment
    )
    BEGIN
        RAISEERROR ('���������� � ����� ��������� ��� ����', 16, 1);
    END
    ELSE
    BEGIN
        INSERT INTO [dbo].[Motorcycle_Equipment]
        SELECT * FROM inserted;
    END
END;